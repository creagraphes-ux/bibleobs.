<!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="theme-color" content="#0b1020">
  <title>OBS Bible Live Studio — Régie</title>
  <link rel="stylesheet" href="assets/app.css">
  <script src="assets/app.js" defer></script>
</head>
<body class="controller-page">
  <section class="login-screen" id="loginScreen" aria-labelledby="loginTitle">
    <div class="login-card">
      <div class="brand-mark">✦</div>
      <p class="eyebrow">RÉGIE DE DIFFUSION</p>
      <h1 id="loginTitle">OBS Bible Live Studio</h1>
      <p class="muted">Connectez-vous pour préparer et projeter les versets dans OBS.</p>
      <form id="loginForm" class="stack-form">
        <label for="loginPassword">Mot de passe de la régie</label>
        <input id="loginPassword" type="password" autocomplete="current-password" required placeholder="Mot de passe défini dans config.php">
        <button class="button button-primary button-wide" type="submit">Ouvrir la régie <span aria-hidden="true">→</span></button>
        <p class="form-message" id="loginMessage" role="status"></p>
      </form>
      <p class="login-footnote">Première installation ? Configurez <code>config.php</code> et importez <code>database.sql</code> avant de vous connecter.</p>
    </div>
  </section>

  <div class="app-shell" id="appShell" hidden>
    <header class="topbar">
      <div class="brand-lockup">
        <div class="brand-mark small-mark">✦</div>
        <div>
          <p class="brand-title">Bible Live <span>Studio</span></p>
          <p class="brand-subtitle">Régie biblique pour OBS</p>
        </div>
      </div>
      <div class="topbar-actions">
        <div class="live-pill" id="livePill"><span class="live-dot"></span><span id="liveLabel">HORS ANTENNE</span></div>
        <button class="button button-quiet button-small" id="logoutButton" type="button">Déconnexion</button>
      </div>
    </header>

    <main class="workspace">
      <div class="page-heading">
        <div>
          <p class="eyebrow">ESPACE DE DIFFUSION · PRODUCTION LOCALE</p>
          <h1>La Parole, <em>en direct.</em></h1>
          <p class="muted">Préparez, vérifiez et envoyez vos passages à l’écran.</p>
        </div>
        <button class="button button-live" id="visibilityButton" type="button">Masquer du flux</button>
      </div>

      <nav class="tabbar" aria-label="Sections de la régie">
        <button class="tab-button active" data-view="control" type="button">Régie directe</button>
        <button class="tab-button" data-view="playlists" type="button">Ordre du culte <span class="tab-count" id="playlistCount">0</span></button>
        <button class="tab-button" data-view="themes" type="button">Apparence</button>
        <button class="tab-button" data-view="library" type="button">Bible</button>
        <button class="tab-button" data-view="obs" type="button">Configuration OBS</button>
      </nav>

      <div class="content-grid">
        <div class="main-column">
          <section class="view active" id="view-control">
            <article class="panel search-panel">
              <div class="panel-heading">
                <div>
                  <p class="eyebrow">01 · RECHERCHE RAPIDE</p>
                  <h2>Trouvez un passage</h2>
                </div>
                <span class="live-icon">⌕</span>
              </div>
              <form id="searchForm" class="search-row">
                <input id="searchQuery" type="search" placeholder="Ex. Jean 3:16, Ps 23:1-4" aria-label="Référence biblique" autocomplete="off">
                <select id="searchTranslation" aria-label="Version biblique"></select>
                <button class="button button-primary" type="submit">Charger <span aria-hidden="true">↗</span></button>
              </form>
              <div class="quick-links" aria-label="Références populaires">
                <span>À portée de main</span>
                <button type="button" data-reference="Jean 3:16">Jean 3:16</button>
                <button type="button" data-reference="Ps 23:1-4">Psaume 23</button>
                <button type="button" data-reference="Rom 8:28">Romains 8:28</button>
                <button type="button" data-reference="Phil 4:13">Philippiens 4:13</button>
                <button type="button" data-reference="Jérémie 29:11">Jérémie 29:11</button>
              </div>
              <p class="form-message" id="searchMessage" role="status"></p>
            </article>

            <article class="panel editor-panel">
              <div class="panel-heading editor-heading">
                <div>
                  <p class="eyebrow">02 · VÉRIFICATION & TEXTE</p>
                  <h2>Préparer le passage</h2>
                </div>
                <button class="button button-quiet button-small" id="addToPlaylistButton" type="button">＋ Ajouter à l’ordre du culte</button>
              </div>
              <div class="reference-grid">
                <label>Livre<select id="bookSelect" required></select></label>
                <label>Chapitre<input id="chapterInput" type="number" min="1" max="150" value="3"></label>
                <label>Verset début<input id="verseStartInput" type="number" min="1" max="300" value="16"></label>
                <label>Verset fin <span class="optional">facultatif</span><input id="verseEndInput" type="number" min="1" max="300" placeholder="—"></label>
              </div>
              <label class="textarea-label" for="verseText">Texte affiché <span>Modifiable avant projection</span></label>
              <textarea id="verseText" rows="5" placeholder="Chargez une référence ou collez ici le texte de votre Bible."></textarea>
              <div class="editor-footer">
                <span class="translation-note" id="translationNote">Traduction : LSG 1910</span>
                <button class="button button-primary project-button" id="projectButton" type="button">Projeter le verset <span aria-hidden="true">↗</span></button>
              </div>
              <p class="form-message" id="projectMessage" role="status"></p>
            </article>

            <article class="panel history-panel">
              <div class="panel-heading">
                <div><p class="eyebrow">MÉMOIRE DE LA SESSION</p><h2>Dernières projections</h2></div>
                <button class="button button-quiet button-small" id="refreshHistoryButton" type="button">Actualiser</button>
              </div>
              <div class="history-list" id="historyList"><p class="empty-state">L’historique apparaîtra ici après vos premières projections.</p></div>
            </article>
          </section>

          <section class="view" id="view-playlists">
            <article class="panel">
              <div class="panel-heading">
                <div><p class="eyebrow">ORDRE DU CULTE · RUN OF SHOW</p><h2>Préparez votre célébration</h2></div>
                <button class="button button-primary button-small" id="newPlaylistButton" type="button">＋ Nouvelle liste</button>
              </div>
              <div class="playlist-toolbar">
                <label class="playlist-select-label">Liste active<select id="playlistSelect"><option value="">Aucune playlist</option></select></label>
                <button class="button button-quiet button-small danger-text" id="deletePlaylistButton" type="button">Supprimer la liste</button>
              </div>
              <p class="muted small-copy" id="playlistDescription">Ajoutez les passages depuis la régie directe pour préparer l’ordre du culte.</p>
              <div class="playlist-list" id="playlistList"><p class="empty-state">Créez une liste puis ajoutez vos passages.</p></div>
            </article>
          </section>

          <section class="view" id="view-themes">
            <article class="panel">
              <div class="panel-heading"><div><p class="eyebrow">IDENTITÉ VISUELLE</p><h2>Choisir le rendu à l’écran</h2></div></div>
              <div class="theme-grid" id="themeGrid">
                <button class="theme-choice active" data-theme="modern" type="button"><span class="theme-swatch swatch-modern"></span><strong>Studio moderne</strong><small>Dégradé nuit et accent doré</small></button>
                <button class="theme-choice" data-theme="glass" type="button"><span class="theme-swatch swatch-glass"></span><strong>Verre dépoli</strong><small>Lower-third discret</small></button>
                <button class="theme-choice" data-theme="gold" type="button"><span class="theme-swatch swatch-gold"></span><strong>Or classique</strong><small>Solennel et chaleureux</small></button>
                <button class="theme-choice" data-theme="broadcast" type="button"><span class="theme-swatch swatch-broadcast"></span><strong>Broadcast</strong><small>Bandeau cyan télévisuel</small></button>
                <button class="theme-choice" data-theme="light" type="button"><span class="theme-swatch swatch-light"></span><strong>Clair</strong><small>Carte lumineuse lisible</small></button>
                <button class="theme-choice" data-theme="cinema" type="button"><span class="theme-swatch swatch-cinema"></span><strong>Cinéma</strong><small>Lecture centrée plein écran</small></button>
              </div>
              <div class="appearance-controls">
                <label>Position<select id="positionSelect"><option value="bottom">Bas de l’écran</option><option value="center">Centre</option><option value="top">Haut de l’écran</option></select></label>
                <label>Animation<select id="animationSelect"><option value="fade-up">Fondu vers le haut</option><option value="fade">Fondu</option><option value="slide-in">Glissement</option><option value="zoom">Zoom doux</option></select></label>
                <label>Taille du texte<select id="fontSizeSelect"><option value="small">Petite</option><option value="medium">Standard</option><option value="large">Grande</option><option value="xl">Très grande</option></select></label>
              </div>
            </article>
          </section>

          <section class="view" id="view-library">
            <article class="panel">
              <div class="panel-heading">
                <div><p class="eyebrow">LECTEUR BIBLIQUE INTÉGRÉ</p><h2>Visualiser la Bible et projeter depuis le chapitre</h2></div>
              </div>
              <div class="reference-grid">
                <label>Version<select id="libraryVersionSelect"></select></label>
                <label>Livre<select id="libraryBookSelect"></select></label>
                <label>Chapitre<input id="libraryChapterInput" type="number" min="1" max="150" value="1"></label>
                <label>&nbsp;<button class="button button-primary button-small button-wide" id="loadChapterButton" type="button">Afficher le chapitre</button></label>
              </div>
              <div class="reader-toolbar">
                <label>Début<input id="libraryVerseStart" type="number" min="1" max="300" value="1"></label>
                <label>Fin<input id="libraryVerseEnd" type="number" min="1" max="300" placeholder="—"></label>
                <button class="button button-quiet button-small" id="projectSelectedRangeButton" type="button">Projeter la sélection</button>
              </div>
              <div class="reader-meta" id="libraryMeta">Choisissez une version et un chapitre.</div>
              <div class="chapter-reader" id="chapterReader"><p class="empty-state">Le chapitre apparaîtra ici.</p></div>
            </article>
          </section>

          <section class="view" id="view-obs">
            <article class="panel setup-panel">
              <p class="eyebrow">DÉMARRAGE OBS · 2 MINUTES</p>
              <h2>Afficher les versets dans OBS</h2>
              <p class="muted">Pas de plugin à installer : la diffusion passe par la Source Navigateur intégrée à OBS.</p>
              <ol class="setup-steps">
                <li><span>1</span><div><strong>Ajoutez une source Navigateur</strong><p>Dans la scène OBS : Sources → + → Navigateur. Nommez-la <code>Bible_Overlay</code>.</p></div></li>
                <li><span>2</span><div><strong>Utilisez l’URL de l’overlay</strong><div class="copy-row"><code id="overlayUrl"></code><button class="button button-quiet button-small" data-copy="overlay" type="button">Copier</button></div></div></li>
                <li><span>3</span><div><strong>Réglez la taille et l’ordre</strong><p>Largeur/hauteur selon votre canevas (souvent 1920 × 1080). Placez la source au-dessus de la caméra.</p></div></li>
                <li><span>4</span><div><strong>Pilotez depuis la régie</strong><p>Gardez la régie ouverte dans un navigateur, ou ajoutez-la comme Dock de navigateur personnalisé dans OBS.</p><div class="copy-row"><code id="controlUrl"></code><button class="button button-quiet button-small" data-copy="control" type="button">Copier</button></div></div></li>
              </ol>
              <div class="notice"><strong>Pour un direct réel :</strong> utilisez votre adresse de site en HTTPS. La Source Navigateur d’OBS et la régie doivent pouvoir joindre ce même hébergement.</div>
              <a class="text-link" id="testOverlayLink" href="overlay.php" target="_blank" rel="noreferrer">Tester l’overlay dans un onglet ↗</a>
            </article>
          </section>
        </div>

        <aside class="side-column">
          <article class="monitor-card">
            <div class="monitor-heading"><span class="monitor-dot"></span><div><p class="eyebrow">MONITEUR RÉGIE</p><strong>Retour du direct</strong></div><span class="resolution-tag">16:9</span></div>
            <div class="preview-screen" id="previewScreen">
              <span class="preview-live-label">APERÇU DU BANDEAU</span>
              <div class="preview-lower-third theme-modern" id="previewCard">
                <div class="preview-reference"><span id="previewReference">Jean 3:16</span><span class="preview-translation" id="previewTranslation">LSG 1910</span></div>
                <p id="previewText">Car Dieu a tant aimé le monde qu’il a donné son Fils unique…</p>
              </div>
            </div>
            <div class="monitor-meta"><div><span>Passage actif</span><strong id="monitorReference">Jean 3:16</strong></div><div><span>Source</span><strong id="sourceStatus">Connexion en cours…</strong></div></div>
            <p class="monitor-footnote">L’overlay vérifie les changements environ une fois par seconde.</p>
          </article>
          <article class="help-card"><span class="help-icon">i</span><div><strong>Astuce régie</strong><p>Testez la source avant le direct et vérifiez qu’elle se trouve au-dessus de la caméra dans la liste OBS.</p></div></article>
        </aside>
      </div>
      <footer class="app-footer"><span>OBS Bible Live Studio</span><span>PHP + MySQL · Compatible hébergement InfinityFree</span></footer>
    </main>
  </div>
</body>
</html>
