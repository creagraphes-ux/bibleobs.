<?php
declare(strict_types=1);

/**
 * Configuration à compléter avec les valeurs visibles dans InfinityFree > MySQL Databases.
 * Remplacez impérativement le mot de passe administrateur avant la mise en ligne.
 */
const DB_HOST = 'sqlXXX.infinityfree.com';
const DB_NAME = 'if0_XXXXXXXX_bible';
const DB_USER = 'if0_XXXXXXXX';
const DB_PASSWORD = 'REMPLACEZ_PAR_LE_MOT_DE_PASSE_MYSQL';
const ADMIN_PASSWORD = 'GjjUFrrFqYVhzxg-2026';
const APP_TIMEZONE = 'UTC';

function infinity_config_is_ready(): bool
{
    return DB_HOST !== 'sqlXXX.infinityfree.com'
        && DB_NAME !== 'if0_XXXXXXXX_bible'
        && DB_USER !== 'if0_XXXXXXXX'
        && DB_PASSWORD !== 'REMPLACEZ_PAR_LE_MOT_DE_PASSE_MYSQL'
        && ADMIN_PASSWORD !== 'CHANGEZ_MOI_POUR_UN_MOT_DE_PASSE_LONG_ET_UNIQUE'
        && strlen(ADMIN_PASSWORD) >= 12;
}
