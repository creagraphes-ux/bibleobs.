-- OBS Bible Live Studio — schéma MySQL/MariaDB pour InfinityFree
-- Sélectionnez d'abord votre base dans phpMyAdmin, puis importez ce fichier.

CREATE TABLE IF NOT EXISTS live_state (
  id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
  is_visible TINYINT(1) NOT NULL DEFAULT 1,
  book VARCHAR(100) NOT NULL DEFAULT 'Jean',
  chapter SMALLINT UNSIGNED NOT NULL DEFAULT 3,
  verse_start SMALLINT UNSIGNED NOT NULL DEFAULT 16,
  verse_end SMALLINT UNSIGNED NULL,
  translation VARCHAR(32) NOT NULL DEFAULT 'LSG 1910',
  version_slug VARCHAR(64) NOT NULL DEFAULT 'lsg-lite',
  verse_text TEXT NOT NULL,
  theme VARCHAR(32) NOT NULL DEFAULT 'modern',
  position VARCHAR(16) NOT NULL DEFAULT 'bottom',
  animation VARCHAR(16) NOT NULL DEFAULT 'fade-up',
  font_size VARCHAR(16) NOT NULL DEFAULT 'medium',
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO live_state (id, is_visible, book, chapter, verse_start, verse_end, translation, version_slug, verse_text, theme, position, animation, font_size)
VALUES (1, 1, 'Jean', 3, 16, NULL, 'LSG 1910', 'lsg-lite', 'Car Dieu a tant aimé le monde qu’il a donné son Fils unique, afin que quiconque croit en lui ne périsse point, mais qu’il ait la vie éternelle.', 'modern', 'bottom', 'fade-up', 'medium');

CREATE TABLE IF NOT EXISTS verse_playlists (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  description TEXT NULL,
  color VARCHAR(16) NOT NULL DEFAULT '#e9b44c',
  items_json LONGTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS display_history (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  reference_text VARCHAR(180) NOT NULL,
  verse_text TEXT NOT NULL,
  translation VARCHAR(32) NOT NULL DEFAULT 'LSG 1910',
  displayed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_displayed_at (displayed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
