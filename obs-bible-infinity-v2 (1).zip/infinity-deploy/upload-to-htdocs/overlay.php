<?php
// Page publique transparente à charger comme Source Navigateur dans OBS.
?><!doctype html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>Overlay biblique — OBS</title>
  <style>
    *{box-sizing:border-box}html,body{width:100%;height:100%;margin:0!important;padding:0!important;overflow:hidden!important;background:transparent!important;color:#fff;font-family:Arial,Helvetica,sans-serif}body{isolation:isolate}.screen{position:fixed;inset:0;display:flex;padding:3.25vh 3.2vw;pointer-events:none}.screen.position-bottom{align-items:flex-end;justify-content:center}.screen.position-center{align-items:center;justify-content:center}.screen.position-top{align-items:flex-start;justify-content:center}.card{position:relative;width:min(100%,1520px);padding:clamp(18px,2.3vw,38px);border-radius:20px;overflow:hidden;opacity:0;transform:translateY(24px) scale(.98);transition:opacity .42s ease,transform .52s cubic-bezier(.2,.8,.2,1);box-shadow:0 20px 70px rgba(0,0,0,.34);will-change:opacity,transform}.card.visible{opacity:1;transform:translateY(0) scale(1)}.card.animation-fade{transform:none}.card.animation-fade.visible{transform:none}.card.animation-slide-in{transform:translateX(-35px)}.card.animation-slide-in.visible{transform:translateX(0)}.card.animation-zoom{transform:scale(.91)}.card.animation-zoom.visible{transform:scale(1)}.card::after{position:absolute;top:-100px;right:-80px;width:260px;height:260px;border-radius:50%;background:rgba(255,255,255,.045);filter:blur(25px);content:"";pointer-events:none}.card.theme-modern{border:1px solid rgba(129,140,248,.34);background:linear-gradient(100deg,rgba(3,8,21,.96),rgba(28,25,67,.92),rgba(4,10,22,.96));color:#f8fafc}.card.theme-glass{border:1px solid rgba(255,255,255,.18);border-left:6px solid #54e0ad;border-radius:4px 18px 18px 4px;background:rgba(5,12,14,.7);backdrop-filter:blur(22px)}.card.theme-gold{border:2px solid rgba(229,180,75,.52);background:linear-gradient(165deg,rgba(37,29,17,.97),rgba(5,5,5,.97));color:#fff5db}.card.theme-broadcast{border:1px solid rgba(56,214,238,.45);border-top:5px solid #32cfe5;border-radius:8px;background:rgba(9,22,37,.96)}.card.theme-light{border:1px solid rgba(15,23,42,.13);background:rgba(255,255,255,.96);color:#111827;box-shadow:0 15px 55px rgba(0,0,0,.25)}.card.theme-cinema{max-width:1250px;border:1px solid rgba(255,255,255,.15);border-radius:26px;background:rgba(0,0,0,.84);text-align:center;backdrop-filter:blur(15px)}.heading{position:relative;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:12px}.reference{color:#f0bd5b;font-size:clamp(19px,2.1vw,34px);font-weight:750;letter-spacing:.045em}.theme-glass .reference{color:#63e6b4}.theme-broadcast .reference{color:#50d9e9;text-transform:uppercase}.theme-light .reference{color:#2556a8}.theme-cinema .heading{justify-content:center}.translation{flex:0 0 auto;padding:5px 10px;border:1px solid rgba(233,180,76,.35);border-radius:999px;background:rgba(233,180,76,.12);color:#f6d58e;font-size:clamp(11px,1vw,15px);font-weight:700;letter-spacing:.04em}.theme-glass .translation{border-color:rgba(84,224,173,.4);background:rgba(84,224,173,.12);color:#a2f5d5}.theme-broadcast .translation{border:0;border-radius:4px;background:#127b9a;color:#fff}.theme-light .translation{border-color:#d8e2f4;background:#eaf1ff;color:#2556a8}.divider{width:90px;height:3px;margin:11px 0 17px;border-radius:9px;background:linear-gradient(90deg,#ecb74f,#6c73ea,#ef7997)}.theme-glass .divider,.theme-broadcast .divider{display:none}.theme-gold .divider{background:#dcb45c}.theme-light .divider{background:#2f63b6}.theme-cinema .divider{margin:14px auto 18px;background:linear-gradient(90deg,transparent,#e7b95c,transparent)}.verse{position:relative;z-index:1;margin:0;color:inherit;font-family:Georgia,'Times New Roman',serif;font-size:clamp(25px,3vw,48px);font-weight:400;font-style:italic;line-height:1.4;letter-spacing:.005em;text-wrap:pretty;text-shadow:0 2px 12px rgba(0,0,0,.18)}.theme-glass .verse,.theme-broadcast .verse{font-family:Arial,Helvetica,sans-serif;font-size:clamp(24px,2.7vw,42px);font-style:normal;font-weight:600;line-height:1.3}.theme-light .verse{color:#263345;text-shadow:none}.theme-cinema .verse{font-size:clamp(34px,4vw,62px);font-style:normal}.card.size-small .verse{font-size:clamp(20px,2.15vw,34px)}.card.size-medium .verse{font-size:clamp(25px,3vw,48px)}.card.size-large .verse{font-size:clamp(32px,3.75vw,60px)}.card.size-xl .verse{font-size:clamp(39px,4.65vw,76px)}.theme-glass .size-small .verse,.theme-broadcast .size-small .verse{font-size:clamp(19px,2vw,32px)}.theme-glass .size-large .verse,.theme-broadcast .size-large .verse{font-size:clamp(31px,3.5vw,55px)}.theme-glass .size-xl .verse,.theme-broadcast .size-xl .verse{font-size:clamp(37px,4.2vw,68px)}
    @media(max-width:700px){.screen{padding:18px}.card{padding:19px;border-radius:14px}.heading{gap:10px}.reference{font-size:17px}.verse{font-size:24px}.card.size-small .verse{font-size:19px}.card.size-medium .verse{font-size:24px}.card.size-large .verse{font-size:30px}.card.size-xl .verse{font-size:36px}}
  </style>
</head>
<body>
  <main class="screen position-bottom" id="screen" aria-live="polite">
    <article class="card theme-modern size-medium animation-fade-up" id="card">
      <div class="heading"><strong class="reference" id="reference"></strong><span class="translation" id="translation"></span></div>
      <div class="divider"></div>
      <p class="verse" id="verse"></p>
    </article>
  </main>
  <script>
    (() => {
      const screen = document.getElementById('screen');
      const card = document.getElementById('card');
      const reference = document.getElementById('reference');
      const translation = document.getElementById('translation');
      const verse = document.getElementById('verse');
      let lastSignature = '';
      const allowed = {
        theme: ['modern', 'glass', 'gold', 'broadcast', 'light', 'cinema'],
        position: ['bottom', 'center', 'top'],
        animation: ['fade', 'fade-up', 'slide-in', 'zoom'],
        fontSize: ['small', 'medium', 'large', 'xl']
      };
      function safe(value, options, fallback) { return options.includes(value) ? value : fallback; }
      function displayState(state) {
        const end = state.verse_end && Number(state.verse_end) !== Number(state.verse_start) ? `-${state.verse_end}` : '';
        const ref = `${state.book} ${state.chapter}:${state.verse_start}${end}`;
        const signature = [state.is_visible, ref, state.translation, state.verse_text, state.theme, state.position, state.animation, state.font_size].join('|');
        if (signature === lastSignature) return;
        lastSignature = signature;
        reference.textContent = ref;
        translation.textContent = state.translation || '';
        verse.textContent = state.verse_text || '';
        screen.className = `screen position-${safe(state.position, allowed.position, 'bottom')}`;
        card.className = `card theme-${safe(state.theme, allowed.theme, 'modern')} size-${safe(state.font_size, allowed.fontSize, 'medium')} animation-${safe(state.animation, allowed.animation, 'fade-up')}`;
        requestAnimationFrame(() => requestAnimationFrame(() => card.classList.toggle('visible', Boolean(state.is_visible))));
      }
      async function poll() {
        try {
          const response = await fetch('api.php?action=state', { cache: 'no-store', credentials: 'same-origin' });
          if (!response.ok) return;
          const data = await response.json();
          if (data && data.success && data.state) displayState(data.state);
        } catch (_) { /* L’overlay conserve le dernier état connu si le réseau est interrompu. */ }
      }
      poll();
      window.setInterval(poll, 1200);
    })();
  </script>
</body>
</html>
