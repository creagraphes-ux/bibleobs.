(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const apiUrl = 'api.php';
  const themes = ['modern', 'glass', 'gold', 'broadcast', 'light', 'cinema'];
  const fallbackBooks = [
    { name: 'Genèse', chapters: 50 }, { name: 'Exode', chapters: 40 }, { name: 'Lévitique', chapters: 27 },
    { name: 'Nombres', chapters: 36 }, { name: 'Deutéronome', chapters: 34 }, { name: 'Josué', chapters: 24 },
    { name: 'Juges', chapters: 21 }, { name: 'Ruth', chapters: 4 }, { name: '1 Samuel', chapters: 31 },
    { name: '2 Samuel', chapters: 24 }, { name: '1 Rois', chapters: 22 }, { name: '2 Rois', chapters: 25 },
    { name: '1 Chroniques', chapters: 29 }, { name: '2 Chroniques', chapters: 36 }, { name: 'Esdras', chapters: 10 },
    { name: 'Néhémie', chapters: 13 }, { name: 'Esther', chapters: 10 }, { name: 'Job', chapters: 42 },
    { name: 'Psaumes', chapters: 150 }, { name: 'Proverbes', chapters: 31 }, { name: 'Ecclésiaste', chapters: 12 },
    { name: 'Cantique des Cantiques', chapters: 8 }, { name: 'Ésaïe', chapters: 66 }, { name: 'Jérémie', chapters: 52 },
    { name: 'Lamentations', chapters: 5 }, { name: 'Ézéchiel', chapters: 48 }, { name: 'Daniel', chapters: 12 },
    { name: 'Osée', chapters: 14 }, { name: 'Joël', chapters: 3 }, { name: 'Amos', chapters: 9 },
    { name: 'Abdias', chapters: 1 }, { name: 'Jonas', chapters: 4 }, { name: 'Michée', chapters: 7 },
    { name: 'Nahum', chapters: 3 }, { name: 'Habacuc', chapters: 3 }, { name: 'Sophonie', chapters: 3 },
    { name: 'Aggée', chapters: 2 }, { name: 'Zacharie', chapters: 14 }, { name: 'Malachie', chapters: 4 },
    { name: 'Matthieu', chapters: 28 }, { name: 'Marc', chapters: 16 }, { name: 'Luc', chapters: 24 },
    { name: 'Jean', chapters: 21 }, { name: 'Actes', chapters: 28 }, { name: 'Romains', chapters: 16 },
    { name: '1 Corinthiens', chapters: 16 }, { name: '2 Corinthiens', chapters: 13 }, { name: 'Galates', chapters: 6 },
    { name: 'Éphésiens', chapters: 6 }, { name: 'Philippiens', chapters: 4 }, { name: 'Colossiens', chapters: 4 },
    { name: '1 Thessaloniciens', chapters: 5 }, { name: '2 Thessaloniciens', chapters: 3 }, { name: '1 Timothée', chapters: 6 },
    { name: '2 Timothée', chapters: 4 }, { name: 'Tite', chapters: 3 }, { name: 'Philémon', chapters: 1 },
    { name: 'Hébreux', chapters: 13 }, { name: 'Jacques', chapters: 5 }, { name: '1 Pierre', chapters: 5 },
    { name: '2 Pierre', chapters: 3 }, { name: '1 Jean', chapters: 5 }, { name: '2 Jean', chapters: 1 },
    { name: '3 Jean', chapters: 1 }, { name: 'Jude', chapters: 1 }, { name: 'Apocalypse', chapters: 22 },
  ];
  const fallbackVersions = [
    { slug: 'lsg-lite', name: 'Louis Segond 1910 (intégrée)', language: 'fr', license: 'public-domain', reader: 'embedded', full: false },
  ];
  let books = [];
  let versions = [];
  let liveState = null;
  let playlists = [];
  let activePlaylistId = '';
  let monitorTimer = null;

  async function request(action, options = {}) {
    const method = options.method || 'GET';
    const url = new URL(apiUrl, window.location.href);
    url.searchParams.set('action', action);
    if (options.query) {
      Object.entries(options.query).forEach(([key, value]) => url.searchParams.set(key, String(value)));
    }
    const response = await fetch(url, {
      method,
      cache: 'no-store',
      credentials: 'same-origin',
      headers: method === 'POST' ? { 'Content-Type': 'application/json' } : undefined,
      body: method === 'POST' ? JSON.stringify(options.body || {}) : undefined,
    });
    let data;
    try { data = await response.json(); } catch { data = { success: false, error: 'Réponse invalide du serveur.' }; }
    if (!response.ok || data.success === false) {
      const error = new Error(data.error || `Erreur HTTP ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return data;
  }

  function showMessage(target, text, success = false) {
    const node = typeof target === 'string' ? $(target) : target;
    if (!node) return;
    node.textContent = text || '';
    node.classList.toggle('success', Boolean(success));
  }

  function refFromState(state) {
    if (!state) return '—';
    const start = state.verse_start ?? state.verseStart ?? 1;
    const end = state.verse_end ?? state.verseEnd;
    const range = end && Number(end) !== Number(start) ? `${start}-${end}` : `${start}`;
    return `${state.book || 'Livre'} ${state.chapter || 1}:${range}`;
  }

  function renderMonitor(state) {
    if (!state) return;
    const ref = refFromState(state);
    $('#monitorReference').textContent = ref;
    $('#previewReference').textContent = ref;
    $('#previewTranslation').textContent = state.translation || 'LSG 1910';
    $('#previewText').textContent = state.verse_text || state.text || 'Aucun texte sélectionné.';
    $('#sourceStatus').textContent = 'Synchronisé';
    const card = $('#previewCard');
    card.classList.remove(...themes.map((theme) => `theme-${theme}`));
    card.classList.add(`theme-${themes.includes(state.theme) ? state.theme : 'modern'}`);
    const live = Boolean(state.is_visible);
    $('#livePill').classList.toggle('on-air', live);
    $('#liveLabel').textContent = live ? 'À L’ANTENNE' : 'HORS ANTENNE';
    $('#visibilityButton').textContent = live ? 'Masquer du flux' : 'Afficher en direct';
    $('#visibilityButton').classList.toggle('is-hidden', !live);
  }

  function fillEditor(state) {
    if (!state) return;
    if (state.book && $('#bookSelect').querySelector(`option[value="${CSS.escape(state.book)}"]`)) {
      $('#bookSelect').value = state.book;
    }
    $('#chapterInput').value = state.chapter || 1;
    $('#verseStartInput').value = state.verse_start || 1;
    $('#verseEndInput').value = state.verse_end || '';
    $('#verseText').value = state.verse_text || '';
    if (state.version_slug && $('#searchTranslation').querySelector(`option[value="${state.version_slug}"]`)) {
      $('#searchTranslation').value = state.version_slug;
    }
    $('#translationNote').textContent = `Version : ${state.translation || 'LSG 1910'}`;
    if (state.book && $('#libraryBookSelect').querySelector(`option[value="${CSS.escape(state.book)}"]`)) {
      $('#libraryBookSelect').value = state.book;
    }
    $('#libraryChapterInput').value = state.chapter || 1;
    $('#libraryVerseStart').value = state.verse_start || 1;
    $('#libraryVerseEnd').value = state.verse_end || '';
    if (state.version_slug && $('#libraryVersionSelect').querySelector(`option[value="${state.version_slug}"]`)) {
      $('#libraryVersionSelect').value = state.version_slug;
    }
    $('#positionSelect').value = state.position || 'bottom';
    $('#animationSelect').value = state.animation || 'fade-up';
    $('#fontSizeSelect').value = state.font_size || 'medium';
    $$('.theme-choice').forEach((button) => button.classList.toggle('active', button.dataset.theme === state.theme));
  }

  function setLiveState(state, updateEditor = true) {
    if (!state) return;
    liveState = state;
    renderMonitor(state);
    if (updateEditor) fillEditor(state);
  }

  function currentPayload() {
    const verseEndValue = $('#verseEndInput').value.trim();
    return {
      book: $('#bookSelect').value,
      chapter: Number($('#chapterInput').value || 1),
      verse_start: Number($('#verseStartInput').value || 1),
      verse_end: verseEndValue ? Number(verseEndValue) : null,
      version_slug: $('#searchTranslation').value,
      translation: selectedVersionName($('#searchTranslation').value),
      verse_text: $('#verseText').value.trim(),
      theme: $('#themeGrid .theme-choice.active')?.dataset.theme || liveState?.theme || 'modern',
      position: $('#positionSelect').value,
      animation: $('#animationSelect').value,
      font_size: $('#fontSizeSelect').value,
    };
  }

  function selectedVersionName(slug) {
    return versions.find((item) => item.slug === slug)?.name || 'Version locale';
  }

  function fillVersionSelects() {
    const targets = ['#searchTranslation', '#libraryVersionSelect'];
    targets.forEach((selector) => {
      const select = $(selector);
      if (!select) return;
      select.replaceChildren();
      versions.forEach((version) => {
        const option = document.createElement('option');
        option.value = version.slug;
        option.textContent = `${version.name}${version.full ? '' : ' · locale'}`;
        select.append(option);
      });
      if (versions.some((version) => version.slug === 'lsg-lite')) {
        select.value = 'lsg-lite';
      }
    });
  }

  function fillBookSelect() {
    ['#bookSelect', '#libraryBookSelect'].forEach((selector) => {
      const select = $(selector);
      if (!select) return;
      select.replaceChildren();
      books.forEach((book) => {
        const option = document.createElement('option');
        option.value = book.name;
        option.textContent = book.name;
        select.append(option);
      });
      if (books.some((book) => book.name === 'Jean')) select.value = 'Jean';
    });
  }

  async function loadState(updateEditor = true) {
    const data = await request('state');
    setLiveState(data.state, updateEditor);
  }

  async function loadCatalog() {
    try {
      const data = await request('catalog');
      books = Array.isArray(data.books) && data.books.length ? data.books : fallbackBooks;
      versions = Array.isArray(data.versions) && data.versions.length ? data.versions : fallbackVersions;
    } catch (_) {
      books = fallbackBooks;
      versions = fallbackVersions;
    }
    fillBookSelect();
    fillVersionSelects();
  }

  async function loadHistory() {
    const host = $('#historyList');
    try {
      const data = await request('history');
      const entries = data.history || [];
      host.replaceChildren();
      if (!entries.length) {
        host.innerHTML = '<p class="empty-state">L’historique apparaîtra ici après vos premières projections.</p>';
        return;
      }
      entries.forEach((entry) => {
        const row = document.createElement('div');
        row.className = 'history-item';
        const details = document.createElement('div');
        const reference = document.createElement('strong');
        reference.textContent = entry.reference_text;
        const text = document.createElement('p');
        text.textContent = `« ${entry.verse_text} » · ${entry.translation}`;
        details.append(reference, text);
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'button button-quiet button-small';
        button.textContent = 'Reprojeter';
        button.addEventListener('click', () => reprojectHistory(entry));
        row.append(details, button);
        host.append(row);
      });
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  function parseReference(reference) {
    const match = String(reference || '').match(/^(.+?)\s+(\d+):(\d+)(?:-(\d+))?$/);
    if (!match) return null;
    const book = books.find((item) => item.name === match[1]);
    if (!book) return null;
    return { book: book.name, chapter: Number(match[2]), verse_start: Number(match[3]), verse_end: match[4] ? Number(match[4]) : null };
  }

  async function reprojectHistory(item) {
    const reference = parseReference(item.reference_text);
    if (!reference) {
      showMessage('#projectMessage', 'Cette référence ne peut pas être relue automatiquement.');
      return;
    }
    await project({ ...reference, translation: item.translation, verse_text: item.verse_text });
  }

  async function searchReference(query) {
    const clean = String(query || '').trim();
    if (!clean) return;
    showMessage('#searchMessage', 'Recherche de l’extrait…');
    try {
      const data = await request('bible', { query: { q: clean, version: $('#searchTranslation').value } });
      const result = data.result;
      $('#bookSelect').value = result.book;
      $('#chapterInput').value = result.chapter;
      $('#verseStartInput').value = result.verseStart;
      $('#verseEndInput').value = result.verseEnd || '';
      $('#verseText').value = result.text;
      $('#searchTranslation').value = result.version_slug;
      $('#translationNote').textContent = `Version : ${result.translation}`;
      showMessage('#searchMessage', `${result.reference} chargé. Vérifiez le texte puis projetez-le.`, true);
      $('#verseText').focus();
    } catch (error) {
      showMessage('#searchMessage', error.message);
    }
  }

  async function loadChapterReader() {
    const version = $('#libraryVersionSelect').value;
    const book = $('#libraryBookSelect').value;
    const chapter = Number($('#libraryChapterInput').value || 1);
    const host = $('#chapterReader');
    $('#libraryMeta').textContent = 'Chargement du chapitre…';
    host.innerHTML = '<p class="empty-state">Chargement…</p>';
    try {
      const data = await request('chapter', { query: { version, book, chapter } });
      const verses = data.chapter.verses || [];
      host.replaceChildren();
      if (!verses.length) {
        host.innerHTML = '<p class="empty-state">Aucun verset trouvé dans ce chapitre.</p>';
        return;
      }
      $('#libraryMeta').textContent = `${selectedVersionName(version)} · ${book} ${chapter} · ${verses.length} versets`;
      verses.forEach((text, index) => {
        const verseNumber = index + 1;
        const row = document.createElement('div');
        row.className = 'chapter-verse';
        const badge = document.createElement('span');
        badge.className = 'chapter-verse-number';
        badge.textContent = String(verseNumber);
        const content = document.createElement('p');
        content.className = 'chapter-verse-text';
        content.textContent = text;
        const actions = document.createElement('div');
        actions.className = 'chapter-verse-actions';
        const projectOne = document.createElement('button');
        projectOne.type = 'button';
        projectOne.className = 'button button-primary button-small';
        projectOne.textContent = 'Projeter';
        projectOne.addEventListener('click', () => project({
          book,
          chapter,
          verse_start: verseNumber,
          verse_end: null,
          version_slug: version,
          translation: selectedVersionName(version),
          verse_text: text,
          theme: $('#themeGrid .theme-choice.active')?.dataset.theme || liveState?.theme || 'modern',
          position: $('#positionSelect').value,
          animation: $('#animationSelect').value,
          font_size: $('#fontSizeSelect').value,
        }));
        const loadToEditor = document.createElement('button');
        loadToEditor.type = 'button';
        loadToEditor.className = 'button button-quiet button-small';
        loadToEditor.textContent = 'Vers l’éditeur';
        loadToEditor.addEventListener('click', () => {
          $('#bookSelect').value = book;
          $('#chapterInput').value = chapter;
          $('#verseStartInput').value = verseNumber;
          $('#verseEndInput').value = '';
          $('#searchTranslation').value = version;
          $('#verseText').value = text;
          $('#translationNote').textContent = `Version : ${selectedVersionName(version)}`;
          setView('control');
        });
        actions.append(projectOne, loadToEditor);
        row.append(badge, content, actions);
        host.append(row);
      });
    } catch (error) {
      $('#libraryMeta').textContent = error.message;
      host.innerHTML = '<p class="empty-state">Chapitre indisponible dans cette version locale.</p>';
    }
  }

  async function projectSelectedRange() {
    const version = $('#libraryVersionSelect').value;
    const book = $('#libraryBookSelect').value;
    const chapter = Number($('#libraryChapterInput').value || 1);
    const verseStart = Number($('#libraryVerseStart').value || 1);
    const verseEnd = $('#libraryVerseEnd').value ? Number($('#libraryVerseEnd').value) : null;
    const query = `${book} ${chapter}:${verseStart}${verseEnd ? `-${verseEnd}` : ''}`;
    try {
      const data = await request('bible', { query: { q: query, version } });
      await project({
        book,
        chapter,
        verse_start: verseStart,
        verse_end: verseEnd,
        version_slug: version,
        translation: data.result.translation,
        verse_text: data.result.text,
        theme: $('#themeGrid .theme-choice.active')?.dataset.theme || liveState?.theme || 'modern',
        position: $('#positionSelect').value,
        animation: $('#animationSelect').value,
        font_size: $('#fontSizeSelect').value,
      });
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  async function project(payload = currentPayload()) {
    if (!payload.verse_text || !payload.verse_text.trim()) {
      showMessage('#projectMessage', 'Chargez ou saisissez le texte avant de le projeter.');
      return;
    }
    showMessage('#projectMessage', 'Envoi vers OBS…');
    $('#projectButton').disabled = true;
    try {
      const data = await request('project', { method: 'POST', body: payload });
      setLiveState(data.state, true);
      showMessage('#projectMessage', `${refFromState(data.state)} est à l’antenne.`, true);
      await loadHistory();
    } catch (error) {
      showMessage('#projectMessage', error.message);
    } finally {
      $('#projectButton').disabled = false;
    }
  }

  async function saveAppearance(patch) {
    try {
      const data = await request('update', { method: 'POST', body: patch });
      setLiveState(data.state, false);
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  async function toggleVisibility() {
    if (!liveState) return;
    try {
      const data = await request('update', { method: 'POST', body: { is_visible: !liveState.is_visible } });
      setLiveState(data.state, false);
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  async function loadPlaylists(preferredId = '') {
    const data = await request('playlists');
    playlists = data.playlists || [];
    const select = $('#playlistSelect');
    select.replaceChildren();
    if (!playlists.length) {
      const empty = document.createElement('option');
      empty.value = '';
      empty.textContent = 'Aucune playlist';
      select.append(empty);
      activePlaylistId = '';
    } else {
      playlists.forEach((playlist) => {
        const option = document.createElement('option');
        option.value = String(playlist.id);
        option.textContent = playlist.name;
        select.append(option);
      });
      const next = preferredId || activePlaylistId;
      activePlaylistId = playlists.some((item) => String(item.id) === String(next)) ? String(next) : String(playlists[0].id);
      select.value = activePlaylistId;
    }
    $('#playlistCount').textContent = String(playlists.length);
    renderPlaylist();
  }

  function currentPlaylist() {
    return playlists.find((item) => String(item.id) === String(activePlaylistId)) || null;
  }

  function renderPlaylist() {
    const host = $('#playlistList');
    const playlist = currentPlaylist();
    host.replaceChildren();
    $('#playlistDescription').textContent = playlist?.description || 'Ajoutez les passages depuis la régie directe pour préparer l’ordre du culte.';
    $('#deletePlaylistButton').disabled = !playlist;
    if (!playlist || !playlist.items?.length) {
      host.innerHTML = '<p class="empty-state">Cette liste est vide. Préparez un passage et ajoutez-le depuis la régie directe.</p>';
      return;
    }
    playlist.items.forEach((item, index) => {
      const row = document.createElement('div');
      row.className = 'playlist-item';
      const number = document.createElement('span');
      number.className = 'playlist-number';
      number.textContent = String(index + 1);
      const details = document.createElement('div');
      const ref = document.createElement('strong');
      ref.textContent = item.reference || `${item.book} ${item.chapter}:${item.verse_start}`;
      const text = document.createElement('p');
      text.textContent = item.verse_text || '';
      details.append(ref, text);
      const actions = document.createElement('div');
      actions.className = 'playlist-item-actions';
      const projectButton = document.createElement('button');
      projectButton.type = 'button';
      projectButton.className = 'button button-primary button-small';
      projectButton.textContent = 'Projeter';
      projectButton.addEventListener('click', () => project(item));
      const removeButton = document.createElement('button');
      removeButton.type = 'button';
      removeButton.className = 'button button-quiet button-small';
      removeButton.textContent = 'Retirer';
      removeButton.addEventListener('click', () => removePlaylistItem(item.id));
      actions.append(projectButton, removeButton);
      row.append(number, details, actions);
      host.append(row);
    });
  }

  async function savePlaylist(playlist) {
    const data = await request('playlist-save', { method: 'POST', body: playlist });
    await loadPlaylists(String(data.playlist.id));
    return data.playlist;
  }

  async function createPlaylist() {
    const name = window.prompt('Nom de la liste (ex. Culte du dimanche)');
    if (!name || !name.trim()) return;
    try {
      const playlist = await savePlaylist({ name: name.trim(), description: '', color: '#e9b44c', items: [] });
      showMessage('#projectMessage', `Liste « ${playlist.name} » créée.`, true);
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  async function addCurrentToPlaylist() {
    const playlist = currentPlaylist();
    if (!playlist) {
      showMessage('#projectMessage', 'Créez d’abord une liste dans l’onglet Ordre du culte.');
      return;
    }
    const payload = currentPayload();
    if (!payload.verse_text) {
      showMessage('#projectMessage', 'Chargez ou saisissez un texte avant de l’ajouter.');
      return;
    }
    const end = payload.verse_end ? `-${payload.verse_end}` : '';
    const item = {
      id: `verse-${Date.now()}`,
      reference: `${payload.book} ${payload.chapter}:${payload.verse_start}${end}`,
      book: payload.book,
      chapter: payload.chapter,
      verse_start: payload.verse_start,
      verse_end: payload.verse_end,
      translation: payload.translation,
      verse_text: payload.verse_text,
    };
    try {
      await savePlaylist({ ...playlist, items: [...(playlist.items || []), item] });
      showMessage('#projectMessage', `${item.reference} ajouté à « ${playlist.name} ».`, true);
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  async function removePlaylistItem(itemId) {
    const playlist = currentPlaylist();
    if (!playlist) return;
    try {
      await savePlaylist({ ...playlist, items: playlist.items.filter((item) => item.id !== itemId) });
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  async function deletePlaylist() {
    const playlist = currentPlaylist();
    if (!playlist || !window.confirm(`Supprimer la liste « ${playlist.name} » ?`)) return;
    try {
      await request('playlist-delete', { method: 'POST', body: { id: playlist.id } });
      await loadPlaylists();
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
  }

  function setView(name) {
    $$('.tab-button').forEach((button) => button.classList.toggle('active', button.dataset.view === name));
    $$('.view').forEach((view) => view.classList.toggle('active', view.id === `view-${name}`));
    if (name === 'playlists') loadPlaylists().catch((error) => showMessage('#projectMessage', error.message));
    if (name === 'obs') {
      $('#overlayUrl').textContent = new URL('overlay.php', window.location.href).href;
      $('#controlUrl').textContent = new URL('./', window.location.href).href;
      $('#testOverlayLink').href = new URL('overlay.php', window.location.href).href;
    }
  }

  async function startController() {
    $('#loginScreen').hidden = true;
    $('#appShell').hidden = false;
    await loadCatalog();
    try {
      await loadState();
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
    try {
      await Promise.all([loadPlaylists(), loadHistory()]);
    } catch (error) {
      showMessage('#projectMessage', error.message);
    }
    try {
      await loadChapterReader();
    } catch (_) {
      // Le lecteur garde un état neutre si le chapitre n'est pas disponible.
    }
    if (monitorTimer) window.clearInterval(monitorTimer);
    monitorTimer = window.setInterval(() => {
      request('state').then((data) => setLiveState(data.state, false)).catch(() => { $('#sourceStatus').textContent = 'Hors ligne'; });
    }, 4000);
  }

  async function initialize() {
    const overlayUrl = new URL('overlay.php', window.location.href).href;
    $('#overlayUrl').textContent = overlayUrl;
    $('#controlUrl').textContent = new URL('./', window.location.href).href;
    $('#testOverlayLink').href = overlayUrl;

    $$('.tab-button').forEach((button) => button.addEventListener('click', () => setView(button.dataset.view)));
    $('#loginForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      showMessage('#loginMessage', 'Connexion…');
      try {
        await request('login', { method: 'POST', body: { password: $('#loginPassword').value } });
        $('#loginPassword').value = '';
        await startController();
      } catch (error) {
        showMessage('#loginMessage', error.message);
      }
    });
    $('#logoutButton').addEventListener('click', async () => {
      try { await request('logout', { method: 'POST' }); } catch (_) {}
      if (monitorTimer) window.clearInterval(monitorTimer);
      $('#appShell').hidden = true;
      $('#loginScreen').hidden = false;
    });
    $('#searchForm').addEventListener('submit', (event) => { event.preventDefault(); searchReference($('#searchQuery').value); });
    $$('.quick-links button[data-reference]').forEach((button) => button.addEventListener('click', () => {
      $('#searchQuery').value = button.dataset.reference;
      searchReference(button.dataset.reference);
    }));
    $('#searchTranslation').addEventListener('change', () => {
      $('#translationNote').textContent = `Version : ${selectedVersionName($('#searchTranslation').value)}`;
    });
    $('#libraryVersionSelect').addEventListener('change', loadChapterReader);
    $('#libraryBookSelect').addEventListener('change', loadChapterReader);
    $('#libraryChapterInput').addEventListener('change', loadChapterReader);
    $('#loadChapterButton').addEventListener('click', loadChapterReader);
    $('#projectSelectedRangeButton').addEventListener('click', projectSelectedRange);
    $('#projectButton').addEventListener('click', () => project());
    $('#visibilityButton').addEventListener('click', toggleVisibility);
    $('#addToPlaylistButton').addEventListener('click', addCurrentToPlaylist);
    $('#refreshHistoryButton').addEventListener('click', loadHistory);
    $('#newPlaylistButton').addEventListener('click', createPlaylist);
    $('#deletePlaylistButton').addEventListener('click', deletePlaylist);
    $('#playlistSelect').addEventListener('change', (event) => { activePlaylistId = event.target.value; renderPlaylist(); });
    $('#positionSelect').addEventListener('change', (event) => saveAppearance({ position: event.target.value }));
    $('#animationSelect').addEventListener('change', (event) => saveAppearance({ animation: event.target.value }));
    $('#fontSizeSelect').addEventListener('change', (event) => saveAppearance({ font_size: event.target.value }));
    $$('.theme-choice').forEach((button) => button.addEventListener('click', () => {
      $$('.theme-choice').forEach((item) => item.classList.toggle('active', item === button));
      saveAppearance({ theme: button.dataset.theme });
    }));
    $$('[data-copy]').forEach((button) => button.addEventListener('click', async () => {
      const value = button.dataset.copy === 'overlay' ? $('#overlayUrl').textContent : $('#controlUrl').textContent;
      try {
        await navigator.clipboard.writeText(value);
        button.textContent = 'Copié !';
        window.setTimeout(() => { button.textContent = 'Copier'; }, 1600);
      } catch (_) {
        window.prompt('Copiez cette adresse :', value);
      }
    }));

    try {
      const auth = await request('auth');
      if (auth.authenticated) await startController();
    } catch (error) {
      showMessage('#loginMessage', error.message);
    }
  }

  document.addEventListener('DOMContentLoaded', initialize);
})();
