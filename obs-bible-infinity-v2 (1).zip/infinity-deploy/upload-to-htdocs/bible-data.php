<?php
declare(strict_types=1);

$BIBLE_BOOKS = [
    ['name' => 'Genèse', 'chapters' => 50], ['name' => 'Exode', 'chapters' => 40],
    ['name' => 'Lévitique', 'chapters' => 27], ['name' => 'Nombres', 'chapters' => 36],
    ['name' => 'Deutéronome', 'chapters' => 34], ['name' => 'Josué', 'chapters' => 24],
    ['name' => 'Juges', 'chapters' => 21], ['name' => 'Ruth', 'chapters' => 4],
    ['name' => '1 Samuel', 'chapters' => 31], ['name' => '2 Samuel', 'chapters' => 24],
    ['name' => '1 Rois', 'chapters' => 22], ['name' => '2 Rois', 'chapters' => 25],
    ['name' => '1 Chroniques', 'chapters' => 29], ['name' => '2 Chroniques', 'chapters' => 36],
    ['name' => 'Esdras', 'chapters' => 10], ['name' => 'Néhémie', 'chapters' => 13],
    ['name' => 'Esther', 'chapters' => 10], ['name' => 'Job', 'chapters' => 42],
    ['name' => 'Psaumes', 'chapters' => 150], ['name' => 'Proverbes', 'chapters' => 31],
    ['name' => 'Ecclésiaste', 'chapters' => 12], ['name' => 'Cantique des Cantiques', 'chapters' => 8],
    ['name' => 'Ésaïe', 'chapters' => 66], ['name' => 'Jérémie', 'chapters' => 52],
    ['name' => 'Lamentations', 'chapters' => 5], ['name' => 'Ézéchiel', 'chapters' => 48],
    ['name' => 'Daniel', 'chapters' => 12], ['name' => 'Osée', 'chapters' => 14],
    ['name' => 'Joël', 'chapters' => 3], ['name' => 'Amos', 'chapters' => 9],
    ['name' => 'Abdias', 'chapters' => 1], ['name' => 'Jonas', 'chapters' => 4],
    ['name' => 'Michée', 'chapters' => 7], ['name' => 'Nahum', 'chapters' => 3],
    ['name' => 'Habacuc', 'chapters' => 3], ['name' => 'Sophonie', 'chapters' => 3],
    ['name' => 'Aggée', 'chapters' => 2], ['name' => 'Zacharie', 'chapters' => 14],
    ['name' => 'Malachie', 'chapters' => 4],
    ['name' => 'Matthieu', 'chapters' => 28], ['name' => 'Marc', 'chapters' => 16],
    ['name' => 'Luc', 'chapters' => 24], ['name' => 'Jean', 'chapters' => 21],
    ['name' => 'Actes', 'chapters' => 28], ['name' => 'Romains', 'chapters' => 16],
    ['name' => '1 Corinthiens', 'chapters' => 16], ['name' => '2 Corinthiens', 'chapters' => 13],
    ['name' => 'Galates', 'chapters' => 6], ['name' => 'Éphésiens', 'chapters' => 6],
    ['name' => 'Philippiens', 'chapters' => 4], ['name' => 'Colossiens', 'chapters' => 4],
    ['name' => '1 Thessaloniciens', 'chapters' => 5], ['name' => '2 Thessaloniciens', 'chapters' => 3],
    ['name' => '1 Timothée', 'chapters' => 6], ['name' => '2 Timothée', 'chapters' => 4],
    ['name' => 'Tite', 'chapters' => 3], ['name' => 'Philémon', 'chapters' => 1],
    ['name' => 'Hébreux', 'chapters' => 13], ['name' => 'Jacques', 'chapters' => 5],
    ['name' => '1 Pierre', 'chapters' => 5], ['name' => '2 Pierre', 'chapters' => 3],
    ['name' => '1 Jean', 'chapters' => 5], ['name' => '2 Jean', 'chapters' => 1],
    ['name' => '3 Jean', 'chapters' => 1], ['name' => 'Jude', 'chapters' => 1],
    ['name' => 'Apocalypse', 'chapters' => 22],
];

$BIBLE_BOOK_ALIASES = [
    'genese' => 'Genèse', 'gen' => 'Genèse', 'ge' => 'Genèse', 'gn' => 'Genèse',
    'ex' => 'Exode', 'exo' => 'Exode', 'lev' => 'Lévitique', 'lv' => 'Lévitique',
    'nb' => 'Nombres', 'deut' => 'Deutéronome', 'dt' => 'Deutéronome',
    'jos' => 'Josué', 'jo' => 'Josué', 'jug' => 'Juges', 'jdg' => 'Juges',
    'rt' => 'Ruth', '1 sa' => '1 Samuel', '1 sam' => '1 Samuel', '2 sa' => '2 Samuel', '2 sam' => '2 Samuel',
    '1 ro' => '1 Rois', '1 roi' => '1 Rois', '2 ro' => '2 Rois', '2 roi' => '2 Rois',
    '1 ch' => '1 Chroniques', '2 ch' => '2 Chroniques', 'esd' => 'Esdras', 'neh' => 'Néhémie',
    'est' => 'Esther', 'ps' => 'Psaumes', 'psa' => 'Psaumes', 'psaume' => 'Psaumes', 'psaumes' => 'Psaumes',
    'prov' => 'Proverbes', 'pr' => 'Proverbes', 'eccl' => 'Ecclésiaste', 'cant' => 'Cantique des Cantiques',
    'ct' => 'Cantique des Cantiques', 'esaie' => 'Ésaïe', 'esa' => 'Ésaïe', 'is' => 'Ésaïe', 'isa' => 'Ésaïe',
    'jer' => 'Jérémie', 'lam' => 'Lamentations', 'ez' => 'Ézéchiel', 'eze' => 'Ézéchiel',
    'dan' => 'Daniel', 'os' => 'Osée', 'joel' => 'Joël', 'am' => 'Amos', 'abd' => 'Abdias',
    'jon' => 'Jonas', 'mic' => 'Michée', 'nah' => 'Nahum', 'hab' => 'Habacuc', 'soph' => 'Sophonie',
    'agg' => 'Aggée', 'zac' => 'Zacharie', 'mal' => 'Malachie',
    'mt' => 'Matthieu', 'mat' => 'Matthieu', 'matt' => 'Matthieu', 'mc' => 'Marc', 'mr' => 'Marc',
    'lc' => 'Luc', 'lu' => 'Luc', 'jn' => 'Jean', 'jhn' => 'Jean', 'ac' => 'Actes', 'act' => 'Actes',
    'ro' => 'Romains', 'rom' => 'Romains', '1 co' => '1 Corinthiens', '1 cor' => '1 Corinthiens', '1co' => '1 Corinthiens',
    '2 co' => '2 Corinthiens', '2 cor' => '2 Corinthiens', '2co' => '2 Corinthiens',
    'ga' => 'Galates', 'gal' => 'Galates', 'ep' => 'Éphésiens', 'eph' => 'Éphésiens',
    'ph' => 'Philippiens', 'phil' => 'Philippiens', 'php' => 'Philippiens', 'col' => 'Colossiens',
    '1 th' => '1 Thessaloniciens', '1 thes' => '1 Thessaloniciens', '2 th' => '2 Thessaloniciens', '2 thes' => '2 Thessaloniciens',
    '1 ti' => '1 Timothée', '1 tim' => '1 Timothée', '2 ti' => '2 Timothée', '2 tim' => '2 Timothée',
    'tit' => 'Tite', 'phm' => 'Philémon', 'heb' => 'Hébreux', 'he' => 'Hébreux', 'jaq' => 'Jacques', 'jac' => 'Jacques',
    '1 pi' => '1 Pierre', '1 p' => '1 Pierre', '1pe' => '1 Pierre', '2 pi' => '2 Pierre', '2 p' => '2 Pierre', '2pe' => '2 Pierre',
    '1 jn' => '1 Jean', '1 jean' => '1 Jean', '1jn' => '1 Jean', '2 jn' => '2 Jean', '2jn' => '2 Jean',
    '3 jn' => '3 Jean', '3jn' => '3 Jean', 'jud' => 'Jude', 'ap' => 'Apocalypse', 'apo' => 'Apocalypse', 'apoc' => 'Apocalypse', 'rev' => 'Apocalypse',
];

// Extraits hors ligne LSG 1910. Les plages ne sont renvoyées que si chaque verset est présent.
$CURATED_VERSES = [
    'Genèse|1|1' => "Au commencement, Dieu créa les cieux et la terre.",
    'Genèse|1|3' => "Dieu dit : Que la lumière soit ! Et la lumière fut.",
    'Josué|1|9' => "Ne t'ai-je pas donné cet ordre : Fortifie-toi et prends courage ? Ne t'effraie point et ne t'épouvante point, car l'Éternel, ton Dieu, est avec toi dans tout ce que tu entreprendras.",
    'Psaumes|23|1' => "L'Éternel est mon berger : je ne manquerai de rien.",
    'Psaumes|23|2' => "Il me fait reposer dans de verts pâturages, Il me dirige près des eaux paisibles.",
    'Psaumes|23|3' => "Il restaure mon âme, Il me conduit dans les sentiers de la justice, À cause de son nom.",
    'Psaumes|23|4' => "Quand je marche dans la vallée de l'ombre de la mort, Je ne crains aucun mal, car tu es avec moi : Ta houlette et ton bâton me rassurent.",
    'Psaumes|91|1' => "Celui qui demeure sous l'abri du Très-Haut Repose à l'ombre du Tout-Puissant.",
    'Psaumes|91|2' => "Je dis à l'Éternel : Mon refuge et ma forteresse, Mon Dieu en qui je me confie !",
    'Psaumes|119|105' => "Ta parole est une lampe à mes pieds, Et une lumière sur mon sentier.",
    'Proverbes|3|5' => "Confie-toi en l'Éternel de tout ton cœur, Et ne t'appuie pas sur ta sagesse ;",
    'Proverbes|3|6' => "Reconnais-le dans toutes tes voies, Et il aplanira tes sentiers.",
    'Ésaïe|40|31' => "Mais ceux qui se confient en l'Éternel renouvellent leur force. Ils prennent le vol comme les aigles ; Ils courent, et ne se lassent point, Ils marchent, et ne se fatiguent point.",
    'Ésaïe|41|10' => "Ne crains rien, car je suis avec toi ; Ne promène pas des regards inquiets, car je suis ton Dieu ; Je te fortifie, je viens à ton secours, Je te soutiens de ma droite triomphante.",
    'Jérémie|29|11' => "Car je connais les projets que j'ai formés sur vous, dit l'Éternel, projets de paix et non de malheur, afin de vous donner un avenir et de l'espérance.",
    'Matthieu|6|33' => "Cherchez premièrement le royaume et la justice de Dieu ; et toutes ces choses vous seront données par-dessus.",
    'Matthieu|28|19' => "Allez, faites de toutes les nations des disciples, les baptisant au nom du Père, du Fils et du Saint-Esprit,",
    'Matthieu|28|20' => "et enseignez-leur à observer tout ce que je vous ai prescrit. Et voici, je suis avec vous tous les jours, jusqu'à la fin du monde.",
    'Jean|1|1' => "Au commencement était la Parole, et la Parole était avec Dieu, et la Parole était Dieu.",
    'Jean|1|14' => "Et la parole a été faite chair, et elle a habité parmi nous, pleine de grâce et de vérité ; et nous avons contemplé sa gloire, une gloire comme la gloire du Fils unique venu du Père.",
    'Jean|3|16' => "Car Dieu a tant aimé le monde qu'il a donné son Fils unique, afin que quiconque croit en lui ne périsse point, mais qu'il ait la vie éternelle.",
    'Jean|3|17' => "Dieu, en effet, n'a pas envoyé son Fils dans le monde pour qu'il juge le monde, mais pour que le monde soit sauvé par lui.",
    'Jean|14|6' => "Jésus lui dit : Je suis le chemin, la vérité, et la vie. Nul ne vient au Père que par moi.",
    'Romains|8|28' => "Nous savons, du reste, que toutes choses concourent au bien de ceux qui aiment Dieu, de ceux qui sont appelés selon son dessein.",
    'Romains|8|31' => "Que dirons-nous donc à l'égard de ces choses ? Si Dieu est pour nous, qui sera contre nous ?",
    'Romains|8|38' => "Car j'ai l'assurance que ni la mort ni la vie, ni les anges ni les dominations, ni les choses présentes ni les choses à venir,",
    'Romains|8|39' => "ni la hauteur, ni la profondeur, ni aucune autre créature ne pourra nous séparer de l'amour de Dieu manifesté en Jésus-Christ notre Seigneur.",
    '1 Corinthiens|13|4' => "La charité est patiente, elle est pleine de bonté ; la charité n'est point envieuse ; la charité ne se vante point, elle ne s'enfle point d'orgueil,",
    '1 Corinthiens|13|13' => "Maintenant donc ces trois choses demeurent : la foi, l'espérance, la charité ; mais la plus grande de ces choses, c'est la charité.",
    'Philippiens|4|6' => "Ne vous inquiétez de rien ; mais en toute chose faites connaître vos besoins à Dieu par des prières et des supplications, avec des actions de grâces.",
    'Philippiens|4|7' => "Et la paix de Dieu, qui surpasse toute intelligence, gardera vos cœurs et vos pensées en Jésus-Christ.",
    'Philippiens|4|13' => "Je puis tout par celui qui me fortifie.",
    '2 Timothée|1|7' => "Car ce n'est pas un esprit de timidité que Dieu nous a donné, mais un esprit de force, d'amour et de sagesse.",
    'Galates|5|22' => "Mais le fruit de l'Esprit, c'est l'amour, la joie, la paix, la patience, la bonté, la bénignité, la fidélité,",
    'Galates|5|23' => "la douceur, la tempérance ; la loi n'est pas contre ces choses.",
    'Hébreux|11|1' => "Or la foi est une ferme assurance des choses qu'on espère, une démonstration de celles qu'on ne voit pas.",
    'Apocalypse|21|4' => "Il essuiera toute larme de leurs yeux, et la mort ne sera plus, et il n'y aura plus ni deuil, ni cri, ni douleur, car les premières choses ont disparu.",
];

function bible_normalize_name(string $value): string
{
    $ascii = function_exists('iconv') ? @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value) : false;
    if (is_string($ascii) && $ascii !== '') {
        $value = $ascii;
    }
    $value = strtolower($value);
    $value = preg_replace('/[^a-z0-9]+/', ' ', $value) ?? '';
    return trim($value);
}

function bible_find_book(string $input): ?array
{
    global $BIBLE_BOOKS, $BIBLE_BOOK_ALIASES;
    $needle = bible_normalize_name($input);
    if ($needle === '') {
        return null;
    }
    foreach ($BIBLE_BOOKS as $book) {
        if (bible_normalize_name($book['name']) === $needle) {
            return $book;
        }
    }
    foreach ($BIBLE_BOOK_ALIASES as $alias => $canonical) {
        if (bible_normalize_name($alias) === $needle) {
            foreach ($BIBLE_BOOKS as $book) {
                if ($book['name'] === $canonical) {
                    return $book;
                }
            }
        }
    }
    return null;
}

function bible_parse_reference(string $query): ?array
{
    $query = trim(preg_replace('/\s+/u', ' ', $query) ?? $query);
    if (!preg_match('/^(.+?)\s+(\d{1,3})\s*[:,.]\s*(\d{1,3})(?:\s*-\s*(\d{1,3}))?$/u', $query, $match)) {
        if (!preg_match('/^(.+?)\s+(\d{1,3})\s+(\d{1,3})(?:\s*-\s*(\d{1,3}))?$/u', $query, $match)) {
            return null;
        }
    }
    $book = bible_find_book(trim($match[1]));
    if ($book === null) {
        return null;
    }
    $chapter = (int) $match[2];
    $verseStart = (int) $match[3];
    $verseEnd = isset($match[4]) && $match[4] !== '' ? (int) $match[4] : null;
    if ($chapter < 1 || $chapter > $book['chapters'] || $verseStart < 1 || ($verseEnd !== null && ($verseEnd < $verseStart || $verseEnd - $verseStart > 10))) {
        return null;
    }
    return ['book' => $book['name'], 'chapter' => $chapter, 'verseStart' => $verseStart, 'verseEnd' => $verseEnd];
}

function bible_lookup(array $reference): ?string
{
    global $CURATED_VERSES;
    $lines = [];
    $last = $reference['verseEnd'] ?? $reference['verseStart'];
    for ($verse = $reference['verseStart']; $verse <= $last; $verse++) {
        $key = $reference['book'] . '|' . $reference['chapter'] . '|' . $verse;
        if (!isset($CURATED_VERSES[$key])) {
            return null;
        }
        $lines[] = ($last > $reference['verseStart'] ? '[' . $verse . '] ' : '') . $CURATED_VERSES[$key];
    }
    return implode(' ', $lines);
}
