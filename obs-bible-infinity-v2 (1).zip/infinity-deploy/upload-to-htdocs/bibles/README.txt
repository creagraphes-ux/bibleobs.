Déposez ici les fichiers JSON de versions bibliques publiques.

Format attendu par version :
- un fichier metadata.json à la racine du dossier de version
- un dossier books contenant un fichier JSON par livre (nom canonique du livre ou code stable)

Structure recommandée :

bibles/
  lsg/
    metadata.json
    books/
      Genèse.json
      Exode.json
      ...
  darby-fr/
    metadata.json
    books/
      Genèse.json
      Exode.json
      ...

Exemple metadata.json :
{
  "slug": "lsg",
  "name": "Louis Segond 1910",
  "language": "fr",
  "license": "public-domain",
  "reader": "open"
}

Exemple de contenu d'un livre :
{
  "book": "Jean",
  "chapters": [
    ["Au commencement était la Parole...", "..."],
    ["Il y avait un homme envoyé de Dieu..."],
    ["Or il y avait, parmi les pharisiens...", "Car Dieu a tant aimé le monde..."]
  ]
}

Chaque chapitre est un tableau de versets; chaque verset est une chaîne.
