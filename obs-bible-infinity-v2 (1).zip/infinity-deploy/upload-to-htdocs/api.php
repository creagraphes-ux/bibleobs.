<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/bible-data.php';
require_once __DIR__ . '/bible-library.php';

date_default_timezone_set(APP_TIMEZONE);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$https = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== '' && strtolower((string) $_SERVER['HTTPS']) !== 'off';
session_name('bible_live_session');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

function api_json(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function api_db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    if (!infinity_config_is_ready()) {
        throw new RuntimeException('Complétez les identifiants et le mot de passe dans config.php.');
    }
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASSWORD, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function api_body(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw === false ? '' : $raw, true);
    if (!is_array($data)) {
        api_json(['success' => false, 'error' => 'Corps JSON invalide.'], 400);
    }
    return $data;
}

function api_require_admin(): void
{
    if (empty($_SESSION['bible_admin'])) {
        api_json(['success' => false, 'error' => 'Session expirée. Connectez-vous à la régie.'], 401);
    }
}

function api_state(PDO $pdo): array
{
    $row = $pdo->query('SELECT * FROM live_state WHERE id = 1 LIMIT 1')->fetch();
    if (!$row) {
        $pdo->exec("INSERT INTO live_state (id, is_visible, book, chapter, verse_start, verse_end, translation, version_slug, verse_text, theme, position, animation, font_size) VALUES (1, 1, 'Jean', 3, 16, NULL, 'LSG 1910', 'lsg-lite', 'Car Dieu a tant aimé le monde qu’il a donné son Fils unique, afin que quiconque croit en lui ne périsse point, mais qu’il ait la vie éternelle.', 'modern', 'bottom', 'fade-up', 'medium')");
        $row = $pdo->query('SELECT * FROM live_state WHERE id = 1 LIMIT 1')->fetch();
    }
    if (!is_array($row)) {
        throw new RuntimeException('La table live_state ne contient pas la ligne principale.');
    }
    $row['is_visible'] = (bool) $row['is_visible'];
    $row['chapter'] = (int) $row['chapter'];
    $row['verse_start'] = (int) $row['verse_start'];
    $row['verse_end'] = $row['verse_end'] === null ? null : (int) $row['verse_end'];
    return $row;
}

function api_reference(array $state): string
{
    $range = (int) $state['verse_start'];
    if ($state['verse_end'] !== null && (int) $state['verse_end'] !== $range) {
        $range .= '-' . (int) $state['verse_end'];
    }
    return $state['book'] . ' ' . (int) $state['chapter'] . ':' . $range;
}

function api_update_state(PDO $pdo, array $input, bool $forceVisible = false): array
{
    $current = api_state($pdo);
    $book = isset($input['book']) ? trim((string) $input['book']) : (string) $current['book'];
    $chapter = isset($input['chapter']) ? filter_var($input['chapter'], FILTER_VALIDATE_INT) : (int) $current['chapter'];
    $verseStart = isset($input['verse_start']) ? filter_var($input['verse_start'], FILTER_VALIDATE_INT) : (int) $current['verse_start'];
    $verseEnd = $current['verse_end'];

    if (array_key_exists('verse_end', $input)) {
        if ($input['verse_end'] === null || $input['verse_end'] === '') {
            $verseEnd = null;
        } else {
            $verseEnd = filter_var($input['verse_end'], FILTER_VALIDATE_INT);
        }
    }

    $text = array_key_exists('verse_text', $input) ? trim((string) $input['verse_text']) : (string) $current['verse_text'];
    $translation = isset($input['translation']) ? trim((string) $input['translation']) : (string) $current['translation'];
    $versionSlug = isset($input['version_slug']) ? trim((string) $input['version_slug']) : (string) ($current['version_slug'] ?? 'lsg-lite');
    $theme = isset($input['theme']) ? (string) $input['theme'] : (string) $current['theme'];
    $position = isset($input['position']) ? (string) $input['position'] : (string) $current['position'];
    $animation = isset($input['animation']) ? (string) $input['animation'] : (string) $current['animation'];
    $fontSize = isset($input['font_size']) ? (string) $input['font_size'] : (string) $current['font_size'];

    if ($book === '' || strlen($book) > 100 || $chapter === false || $chapter < 1 || $chapter > 150 || $verseStart === false || $verseStart < 1 || $verseStart > 300) {
        api_json(['success' => false, 'error' => 'Livre, chapitre ou numéro de verset invalide.'], 422);
    }
    if ($verseEnd !== null && ($verseEnd === false || $verseEnd < $verseStart || $verseEnd > 300)) {
        api_json(['success' => false, 'error' => 'La plage de versets est invalide.'], 422);
    }
    if (strlen($text) > 10000) {
        api_json(['success' => false, 'error' => 'Le texte est trop long (10 000 caractères maximum).'], 422);
    }
    if (strlen($translation) > 32) {
        api_json(['success' => false, 'error' => 'Nom de traduction trop long.'], 422);
    }
    $availableVersions = array_column(bible_versions_catalog(), 'slug');
    if ($versionSlug === '' || !in_array($versionSlug, $availableVersions, true)) {
        api_json(['success' => false, 'error' => 'Version biblique non reconnue.'], 422);
    }
    $allowedThemes = ['modern', 'glass', 'gold', 'broadcast', 'light', 'cinema'];
    $allowedPositions = ['bottom', 'center', 'top'];
    $allowedAnimations = ['fade', 'fade-up', 'slide-in', 'zoom'];
    $allowedSizes = ['small', 'medium', 'large', 'xl'];
    if (!in_array($theme, $allowedThemes, true) || !in_array($position, $allowedPositions, true) || !in_array($animation, $allowedAnimations, true) || !in_array($fontSize, $allowedSizes, true)) {
        api_json(['success' => false, 'error' => 'Option d’affichage non reconnue.'], 422);
    }

    $visible = $forceVisible ? true : (array_key_exists('is_visible', $input) ? filter_var($input['is_visible'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) : (bool) $current['is_visible']);
    if ($visible === null) {
        api_json(['success' => false, 'error' => 'Visibilité invalide.'], 422);
    }

    $stmt = $pdo->prepare('UPDATE live_state SET is_visible = :visible, book = :book, chapter = :chapter, verse_start = :verse_start, verse_end = :verse_end, translation = :translation, version_slug = :version_slug, verse_text = :verse_text, theme = :theme, position = :position, animation = :animation, font_size = :font_size WHERE id = 1');
    $stmt->execute([
        ':visible' => $visible ? 1 : 0,
        ':book' => $book,
        ':chapter' => $chapter,
        ':verse_start' => $verseStart,
        ':verse_end' => $verseEnd,
        ':translation' => $translation !== '' ? $translation : 'LSG 1910',
        ':version_slug' => $versionSlug,
        ':verse_text' => $text,
        ':theme' => $theme,
        ':position' => $position,
        ':animation' => $animation,
        ':font_size' => $fontSize,
    ]);
    return api_state($pdo);
}

function api_playlist_items(string $json): array
{
    $items = json_decode($json, true);
    return is_array($items) ? $items : [];
}

$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
$action = (string) ($_GET['action'] ?? '');

try {
    if ($method === 'GET') {
        if ($action === 'state') {
            api_json(['success' => true, 'state' => api_state(api_db())]);
        }
        if ($action === 'auth') {
            api_json(['success' => true, 'authenticated' => !empty($_SESSION['bible_admin'])]);
        }
        if ($action === 'catalog') {
            api_json([
                'success' => true,
                'books' => $BIBLE_BOOKS,
                'versions' => bible_versions_catalog(),
                'translations' => [
                    ['code' => 'LSG 1910', 'name' => 'Louis Segond 1910'],
                    ['code' => 'Darby FR', 'name' => 'Bible Darby Française'],
                    ['code' => 'Martin 1744', 'name' => 'Bible David Martin 1744'],
                    ['code' => 'Texte personnalisé', 'name' => 'Texte personnalisé'],
                ],
            ]);
        }
        if ($action === 'bible') {
            $query = trim((string) ($_GET['q'] ?? ''));
            $versionSlug = trim((string) ($_GET['version'] ?? 'lsg-lite'));
            $reference = bible_parse_reference($query);
            if ($reference === null) {
                api_json(['success' => false, 'error' => 'Référence non reconnue. Essayez par exemple Jean 3:16 ou Ps 23:1-4.'], 422);
            }
            $text = bible_extract_passage($versionSlug, $reference['book'], (int) $reference['chapter'], (int) $reference['verseStart'], $reference['verseEnd']);
            if ($text === null) {
                api_json(['success' => false, 'error' => 'Ce passage n’est pas disponible dans la version locale choisie. Ajoutez la version complète dans /bibles ou collez le texte dans l’éditeur.'], 404);
            }
            $range = $reference['verseStart'];
            if ($reference['verseEnd'] !== null) {
                $range .= '-' . $reference['verseEnd'];
            }
            $versions = bible_versions_catalog();
            $currentVersion = null;
            foreach ($versions as $item) {
                if ($item['slug'] === $versionSlug) {
                    $currentVersion = $item;
                    break;
                }
            }
            api_json(['success' => true, 'result' => $reference + ['reference' => $reference['book'] . ' ' . $reference['chapter'] . ':' . $range, 'translation' => $currentVersion['name'] ?? 'Version locale', 'version_slug' => $versionSlug, 'text' => $text]]);
        }
        if ($action === 'chapter') {
            $book = trim((string) ($_GET['book'] ?? ''));
            $chapter = filter_var($_GET['chapter'] ?? null, FILTER_VALIDATE_INT);
            $versionSlug = trim((string) ($_GET['version'] ?? 'lsg-lite'));
            if ($book === '' || $chapter === false || $chapter < 1) {
                api_json(['success' => false, 'error' => 'Livre ou chapitre invalide.'], 422);
            }
            $chapterData = bible_get_chapter($versionSlug, $book, $chapter);
            if ($chapterData === null) {
                api_json(['success' => false, 'error' => 'Chapitre indisponible dans cette version locale.'], 404);
            }
            api_json(['success' => true, 'chapter' => $chapterData]);
        }
        if ($action === 'playlists') {
            api_require_admin();
            $rows = api_db()->query('SELECT id, name, description, color, items_json FROM verse_playlists ORDER BY updated_at DESC, id DESC')->fetchAll();
            foreach ($rows as &$row) {
                $row['id'] = (int) $row['id'];
                $row['items'] = api_playlist_items((string) $row['items_json']);
                unset($row['items_json']);
            }
            unset($row);
            api_json(['success' => true, 'playlists' => $rows]);
        }
        if ($action === 'history') {
            api_require_admin();
            $rows = api_db()->query('SELECT id, reference_text, verse_text, translation, displayed_at FROM display_history ORDER BY displayed_at DESC, id DESC LIMIT 30')->fetchAll();
            api_json(['success' => true, 'history' => $rows]);
        }
        api_json(['success' => false, 'error' => 'Action API inconnue.'], 404);
    }

    if ($method !== 'POST') {
        header('Allow: GET, POST');
        api_json(['success' => false, 'error' => 'Méthode non autorisée.'], 405);
    }

    $input = api_body();
    if ($action === 'login') {
        if (!infinity_config_is_ready()) {
            api_json(['success' => false, 'error' => 'Configurez d’abord les identifiants MySQL et un mot de passe administrateur (12 caractères minimum) dans config.php.'], 503);
        }
        $password = (string) ($input['password'] ?? '');
        if (!hash_equals(ADMIN_PASSWORD, $password)) {
            usleep(250000);
            api_json(['success' => false, 'error' => 'Mot de passe incorrect.'], 401);
        }
        session_regenerate_id(true);
        $_SESSION['bible_admin'] = true;
        api_json(['success' => true, 'authenticated' => true]);
    }
    if ($action === 'logout') {
        $_SESSION = [];
        session_destroy();
        api_json(['success' => true]);
    }

    api_require_admin();
    $pdo = api_db();

    if ($action === 'project') {
        $text = trim((string) ($input['verse_text'] ?? ''));
        if ($text === '') {
            api_json(['success' => false, 'error' => 'Ajoutez le texte du passage avant de le projeter.'], 422);
        }
        $state = api_update_state($pdo, $input, true);
        $insert = $pdo->prepare('INSERT INTO display_history (reference_text, verse_text, translation) VALUES (:reference, :text, :translation)');
        $insert->execute([':reference' => api_reference($state), ':text' => $state['verse_text'], ':translation' => $state['translation']]);
        api_json(['success' => true, 'state' => $state]);
    }
    if ($action === 'update') {
        api_json(['success' => true, 'state' => api_update_state($pdo, $input)]);
    }
    if ($action === 'playlist-save') {
        $id = isset($input['id']) ? (int) $input['id'] : 0;
        $name = trim((string) ($input['name'] ?? ''));
        $description = trim((string) ($input['description'] ?? ''));
        $color = (string) ($input['color'] ?? '#e9b44c');
        $items = $input['items'] ?? [];
        if ($name === '' || strlen($name) > 160 || !is_array($items) || count($items) > 100 || !preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
            api_json(['success' => false, 'error' => 'Nom, couleur ou contenu de playlist invalide.'], 422);
        }
        foreach ($items as $item) {
            if (!is_array($item) || empty($item['book']) || empty($item['verse_text']) || strlen((string) $item['verse_text']) > 10000) {
                api_json(['success' => false, 'error' => 'Un élément de la playlist est incomplet.'], 422);
            }
        }
        $itemsJson = json_encode(array_values($items), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($itemsJson === false) {
            api_json(['success' => false, 'error' => 'Impossible d’encoder cette playlist.'], 422);
        }
        if ($id > 0) {
            $stmt = $pdo->prepare('UPDATE verse_playlists SET name = :name, description = :description, color = :color, items_json = :items WHERE id = :id');
            $stmt->execute([':name' => $name, ':description' => $description, ':color' => $color, ':items' => $itemsJson, ':id' => $id]);
            if ($stmt->rowCount() === 0) {
                $exists = $pdo->prepare('SELECT id FROM verse_playlists WHERE id = :id');
                $exists->execute([':id' => $id]);
                if (!$exists->fetch()) {
                    api_json(['success' => false, 'error' => 'Playlist introuvable.'], 404);
                }
            }
        } else {
            $stmt = $pdo->prepare('INSERT INTO verse_playlists (name, description, color, items_json) VALUES (:name, :description, :color, :items)');
            $stmt->execute([':name' => $name, ':description' => $description, ':color' => $color, ':items' => $itemsJson]);
            $id = (int) $pdo->lastInsertId();
        }
        api_json(['success' => true, 'playlist' => ['id' => $id, 'name' => $name, 'description' => $description, 'color' => $color, 'items' => array_values($items)]]);
    }
    if ($action === 'playlist-delete') {
        $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
        if ($id === false || $id < 1) {
            api_json(['success' => false, 'error' => 'Identifiant de playlist invalide.'], 422);
        }
        $stmt = $pdo->prepare('DELETE FROM verse_playlists WHERE id = :id');
        $stmt->execute([':id' => $id]);
        api_json(['success' => true]);
    }
    api_json(['success' => false, 'error' => 'Action API inconnue.'], 404);
} catch (Throwable $error) {
    error_log('[OBS Bible Live] ' . $error->getMessage());
    $message = !infinity_config_is_ready()
        ? 'Complétez config.php avec les identifiants de votre base MySQL InfinityFree et un mot de passe régie.'
        : 'Le serveur n’a pas pu traiter la demande. Vérifiez que database.sql a été importé et que config.php est correct.';
    api_json(['success' => false, 'error' => $message], 500);
}
