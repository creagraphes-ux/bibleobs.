<?php
declare(strict_types=1);

require_once __DIR__ . '/bible-data.php';

function bible_versions_catalog(): array
{
    $builtin = [
        [
            'slug' => 'lsg-lite',
            'name' => 'Louis Segond 1910 (intégrée)',
            'language' => 'fr',
            'license' => 'public-domain',
            'reader' => 'embedded',
            'full' => false,
        ],
    ];

    $base = __DIR__ . '/bibles';
    if (!is_dir($base)) {
        return $builtin;
    }

    $entries = scandir($base);
    if (!is_array($entries)) {
        return $builtin;
    }

    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }
        $dir = $base . '/' . $entry;
        $metaFile = $dir . '/metadata.json';
        if (!is_dir($dir) || !is_file($metaFile)) {
            continue;
        }
        $json = file_get_contents($metaFile);
        if ($json === false) {
            continue;
        }
        $meta = json_decode($json, true);
        if (!is_array($meta) || empty($meta['slug']) || empty($meta['name'])) {
            continue;
        }
        $builtin[] = [
            'slug' => (string) $meta['slug'],
            'name' => (string) $meta['name'],
            'language' => (string) ($meta['language'] ?? 'fr'),
            'license' => (string) ($meta['license'] ?? 'unknown'),
            'reader' => (string) ($meta['reader'] ?? 'open'),
            'full' => true,
        ];
    }

    return $builtin;
}

function bible_find_book_index(string $bookName): ?int
{
    global $BIBLE_BOOKS;
    foreach ($BIBLE_BOOKS as $index => $book) {
        if ($book['name'] === $bookName) {
            return $index;
        }
    }
    return null;
}

function bible_load_full_book(string $versionSlug, string $bookName): ?array
{
    if ($versionSlug === 'lsg-lite') {
        return bible_build_embedded_book($bookName);
    }

    $file = __DIR__ . '/bibles/' . $versionSlug . '/books/' . $bookName . '.json';
    if (!is_file($file)) {
        return null;
    }
    $json = file_get_contents($file);
    if ($json === false) {
        return null;
    }
    $book = json_decode($json, true);
    if (!is_array($book) || empty($book['chapters']) || !is_array($book['chapters'])) {
        return null;
    }
    return $book;
}

function bible_build_embedded_book(string $bookName): ?array
{
    global $CURATED_VERSES;
    $index = bible_find_book_index($bookName);
    if ($index === null) {
        return null;
    }
    $chapters = [];
    foreach ($CURATED_VERSES as $key => $text) {
        [$book, $chapter, $verse] = explode('|', $key);
        if ($book !== $bookName) {
            continue;
        }
        $chapterNumber = (int) $chapter;
        $verseNumber = (int) $verse;
        if (!isset($chapters[$chapterNumber])) {
            $chapters[$chapterNumber] = [];
        }
        $chapters[$chapterNumber][$verseNumber] = $text;
    }
    if (!$chapters) {
        return null;
    }
    ksort($chapters);
    $normalized = [];
    foreach ($chapters as $chapterNumber => $verses) {
        ksort($verses);
        $normalized[$chapterNumber - 1] = array_values($verses);
    }
    ksort($normalized);
    return [
        'book' => $bookName,
        'chapters' => array_values($normalized),
    ];
}

function bible_get_chapter(string $versionSlug, string $bookName, int $chapter): ?array
{
    $book = bible_load_full_book($versionSlug, $bookName);
    if ($book === null) {
        return null;
    }
    $index = $chapter - 1;
    if (!isset($book['chapters'][$index]) || !is_array($book['chapters'][$index])) {
        return null;
    }
    return [
        'book' => $bookName,
        'chapter' => $chapter,
        'verses' => array_values($book['chapters'][$index]),
    ];
}

function bible_extract_passage(string $versionSlug, string $bookName, int $chapter, int $verseStart, ?int $verseEnd = null): ?string
{
    $chapterData = bible_get_chapter($versionSlug, $bookName, $chapter);
    if ($chapterData === null) {
        return null;
    }
    $verseEnd = $verseEnd ?? $verseStart;
    $slice = [];
    for ($verse = $verseStart; $verse <= $verseEnd; $verse++) {
        $index = $verse - 1;
        if (!isset($chapterData['verses'][$index])) {
            return null;
        }
        $slice[] = ($verseEnd > $verseStart ? '[' . $verse . '] ' : '') . trim((string) $chapterData['verses'][$index]);
    }
    return implode(' ', $slice);
}
