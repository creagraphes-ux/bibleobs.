OBS BIBLE LIVE STUDIO — EDITION INFINITYFREE
============================================

Cette archive est une adaptation autonome PHP + MySQL/MariaDB pour l’hébergement partagé InfinityFree. Elle ne nécessite ni Node.js, ni Next.js, ni PostgreSQL, ni SSH, ni Composer.

CONTENU
-------
upload-to-htdocs/   Fichiers du site à envoyer dans le dossier htdocs de votre compte.

AVANT DE COMMENCER
------------------
Vous devez avoir un compte InfinityFree actif, une adresse de site (sous-domaine gratuit ou domaine), et les informations MySQL affichées par votre panneau de contrôle. Le nom d’hôte MySQL fourni par InfinityFree n’est généralement pas « localhost » : utilisez exactement la valeur du panneau.

INSTALLATION SUR INFINITYFREE
-----------------------------
1. Dans InfinityFree, ouvrez le Control Panel de votre site puis « MySQL Databases ».
2. Créez une base MySQL. Notez le nom de base, l’utilisateur, le mot de passe et l’hôte/serveur MySQL.
3. Ouvrez phpMyAdmin depuis cette page. Sélectionnez la base que vous venez de créer, ouvrez l’onglet « Importer », choisissez upload-to-htdocs/database.sql sur votre ordinateur, puis lancez l’import.
4. Ouvrez le gestionnaire de fichiers ou connectez-vous en FTP. Entrez dans le dossier htdocs. Supprimez la page d’accueil temporaire si elle masque le site.
5. Envoyez le CONTENU du dossier upload-to-htdocs dans htdocs : index.php, overlay.php, api.php, config.php, bible-data.php, database.sql, .htaccess et assets/. Ne laissez pas les fichiers dans un sous-dossier upload-to-htdocs sur le serveur.
6. Dans le gestionnaire de fichiers, éditez htdocs/config.php. Remplacez DB_HOST, DB_NAME, DB_USER, DB_PASSWORD par les valeurs exactes du panneau MySQL. Remplacez ADMIN_PASSWORD par un mot de passe long et unique d’au moins 12 caractères. Ne partagez pas ce mot de passe.
7. Activez/attendez le certificat SSL de votre site dans le panneau et utilisez ensuite son adresse HTTPS.
8. Ouvrez https://VOTRE-SITE/ dans un navigateur. Connectez-vous avec ADMIN_PASSWORD. Ouvrez ensuite https://VOTRE-SITE/api.php?action=state : une réponse JSON avec success=true signifie que l’API et la base répondent. Essayez enfin https://VOTRE-SITE/overlay.php.

UTILISATION DANS OBS
--------------------
1. Dans OBS, sélectionnez la scène de diffusion et cliquez Sources → + → Navigateur.
2. Nommez la source Bible_Overlay.
3. URL : https://VOTRE-SITE/overlay.php (remplacez par votre vrai domaine).
4. Taille : les dimensions de votre canevas, généralement 1920 × 1080.
5. Cliquez OK. Placez Bible_Overlay au-dessus de la caméra dans la liste des sources.
6. Gardez https://VOTRE-SITE/ ouvert sur l’ordinateur du régisseur ou ajoutez cette URL comme Dock de navigateur personnalisé d’OBS.
7. Connectez-vous, cherchez par exemple Jean 3:16, vérifiez le texte et cliquez « Projeter le verset ». Utilisez « Masquer du flux » pour le retirer.

FONCTIONNALITÉS ET LIMITES DE CETTE ÉDITION
-------------------------------------------
- Régie PHP protégée par le mot de passe configuré.
- Overlay public à fond réellement transparent, actualisé périodiquement par l’API PHP.
- État live, affichage/masquage, 6 thèmes, 3 positions, 4 tailles et 4 animations.
- Playlists MySQL, historique des projections et texte modifiable.
- Le moteur hors ligne embarque des extraits LSG 1910 populaires.
- Un vrai lecteur biblique est inclus dans l’onglet « Bible » avec visualisation du chapitre, projection d’un verset et projection d’une plage.
- Vous pouvez ajouter des versions complètes locales dans le dossier htdocs/bibles/ (voir bibles/README.txt). Chaque version ajoutée apparaît automatiquement dans la régie.
- Aucun plugin natif OBS n’est fourni : l’intégration est la Source Navigateur intégrée à OBS. Aucun script Lua n’est nécessaire.
- Une requête légère de synchronisation est envoyée environ toutes les 1,2 seconde pendant que l’overlay est ouvert.

DÉPANNAGE RAPIDE
----------------
• « Configurez config.php » : vérifiez les quatre identifiants MySQL et le mot de passe régie.
• Erreur base/table absente : vérifiez que database.sql a été importé dans la bonne base sélectionnée dans phpMyAdmin.
• L’overlay reste vide : ouvrez /api.php?action=state, puis /overlay.php dans un navigateur; actualisez ensuite la Source Navigateur dans OBS.
• L’image n’est pas transparente : vérifiez que l’URL se termine bien par /overlay.php et que la source ne contient pas de CSS OBS personnalisé qui ajoute un fond opaque.
• Le contrôleur demande toujours le mot de passe : autorisez les cookies du site et utilisez le même domaine pour la régie et l’overlay.
• Ne mettez jamais les identifiants MySQL dans assets/app.js, dans une URL publique ou dans un message.

Le panneau du fournisseur et les intitulés peuvent évoluer. En cas de différence, utilisez les valeurs de connexion indiquées dans votre propre panneau InfinityFree.
